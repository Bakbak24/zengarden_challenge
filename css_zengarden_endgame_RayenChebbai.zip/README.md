Hier is de github link van de volledige zengarden website https://github.com/Bakbak24/zengarden_challenge
Link van site: https://zengarden-challenge.vercel.app/

Probeer zelf te zoeken waar de content(teksten) verstopt liggen bij de Notre dame kerk.

Tip: Hover over de gargoyle standbeeldjes🦇 of het raampjes🪟!

Zengarden Guide Youtube Video: https://youtu.be/MOIYGfvfBwI?feature=shared
